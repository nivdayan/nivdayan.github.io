#ifndef HASH_TABLE_GUARD
#define HASH_TABLE_GUARD

#include <stdio.h>

int get(int key);
void put(int key, int value);
void erase(int key);


#endif
