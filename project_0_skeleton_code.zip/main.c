// File: main.c
#include "hash_table.h"

int main(void) {
  put(0, 1);
  get(0);
  erase(0);
  return 0;
}
