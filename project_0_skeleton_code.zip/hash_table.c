
#include "hash_table.h"

int get(int key) {
  return -1;
}

void put(int key, int value) {
}

void erase(int key) {
}
